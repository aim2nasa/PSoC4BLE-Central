#ifndef UTIL_H
#define UTIL_H
    
void clearDisplay(void);

#endif